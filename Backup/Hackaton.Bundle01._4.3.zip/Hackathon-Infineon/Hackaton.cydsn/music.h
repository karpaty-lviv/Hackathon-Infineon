#ifndef MUSIC_H
#define MUSIC_H

#ifdef __cplusplus
extern "C" {
#endif
    
void Music_FurElise(void);
void Music_Music_ViennaWaltz(void);

#ifdef __cplusplus
}
#endif

#endif /* MUSIC_H */
 